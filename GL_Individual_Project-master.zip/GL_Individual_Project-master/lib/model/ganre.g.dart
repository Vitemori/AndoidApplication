// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ganre.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Ganre _$GanreFromJson(Map<String, dynamic> json) => Ganre(
      id: json['id'] as int,
      name: json['name'] as String,
    );

Map<String, dynamic> _$GanreToJson(Ganre instance) => <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
    };
