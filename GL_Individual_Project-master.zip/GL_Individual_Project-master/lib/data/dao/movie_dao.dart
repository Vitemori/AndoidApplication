import 'package:floor/floor.dart';
import 'package:individual_project/model/ganre.dart';
import 'package:individual_project/model/ganre_movie_id.dart';
import 'package:individual_project/model/movie.dart';
import 'package:individual_project/service/moviedb.dart';

@dao
abstract class MovieDao {
  // @Query('SELECT * FROM Movie Where label = :query AND ganre = :selectedGanre')
  // Stream<List<Movie>> findPopularMovie(String query, int selectedGanre);

  // @Query('SELECT * FROM Movie INNER JOIN GanreAndMovie '
  //     'ON Movie.id = GanreAndMovie.movieId INNER JOIN Ganre'
  //     'On GanreAndMovie.ganreId = Ganre.id'
  //     'Where Ganre.id = :selectedGanre')
  // Stream<List<Movie>> findMovieByGanre(int selectedGanre);

  @Query(
      'SELECT * FROM Movie Where id IN (SELECT movieId FROM GanreAndMovie WHERE ganreId = :selectedGanre)')
  Stream<List<Movie>> findMovieByGanre(int selectedGanre);

  @Query('SELECT * FROM Movie')
  Stream<List<Movie>> findAllMovie();

  @Query('SELECT * FROM Ganre')
  Stream<List<Ganre>> findAllGanre();

  @insert
  Future<void> insertMovie(Movie movie);

  @insert
  Future<void> insertGanre(Ganre ganre);

  @insert
  Future<void> insertGanreAndMovie(GanreAndMovie ganreAndMovie);

  @insert
  Future<List<int>> insertListMovie(List<Movie> movie);

  @insert
  Future<List<int>> insertListGanre(List<Ganre> ganre);

  @Query('DELETE FROM Movie')
  Future<void> deleteAllMovies();

  @Query('DELETE FROM GanreAndMovie')
  Future<void> deleteAllGanreAndMovies();

  @Query('DELETE FROM Ganre')
  Future<void> deleteAllGanre();

  @Query('DELETE FROM Movie Where id = :id')
  Future<void> deleteMovieById(int id);

  @transaction
  Future<void> replaceMovies(List<Movie> movie) async {
    for (var element in movie) {
      await deleteMovieById(element.id);
      await insertMovie(element);
    }
  }

  Future<void> createGanreList({required MovieDB apiMovieDb}) async {
    List<Ganre> ganreMovieList = await apiMovieDb.getGenreList();
    insertListGanre(ganreMovieList);
  }

  Future<void> createMovieList(
      {required MovieDB apiMovieDb, required int selectedGanre}) async {
    try {
      List<Movie> movieList;
      if (selectedGanre == 2) {
        movieList = await apiMovieDb.getPopularMovie();
        print('try1');
      } else if (selectedGanre == 1) {
        movieList = await apiMovieDb.getNowPlayingMovie();
        print('try2');
      } else {
        movieList = await apiMovieDb.getMovieByGanre(selectedGanre);
        print('try3');
      }
      replaceMovies(movieList);

      for (var element in movieList) {
        insertGanreAndMovie(
            GanreAndMovie(ganreId: selectedGanre, movieId: element.id));
      }

      print('tryeeeeeee');
    } catch (e) {
      throw Exception('Error is $e');
    }
  }
}
