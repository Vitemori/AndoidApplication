const String homePage = '/';
const String movieDetailPage = '/movieDetailPage';
const String personDetailPage = '/personDetailPage';
const String searchMoviePage = '/searchMoviePage';