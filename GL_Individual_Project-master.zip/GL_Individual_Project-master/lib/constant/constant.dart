class Constant {
  static double kBlur = 15;
  static String kHomeBackgroundPhoto = 'assets/moviedb.png';
  static String kNoPhoto = 'assets/no_photo.jpg';
  static double kNowPlayHeigh = 2;
  static double kMovieWidth = 1.7;
  static double kMovieHeigh = 3;
  static double kMovieDetailCastImageSize = 80;
  static String kphoto = 'https://image.tmdb.org/t/p/w500/';
}